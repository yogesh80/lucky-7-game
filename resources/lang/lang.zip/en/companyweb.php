<?php

return [
   
    'SAVE TIME, MONEY, TREES, AND EVEN LIVES.' =>'SAVE TIME, MONEY, TREES, AND EVEN LIVES.',
    'Start Selling Online For Free'=>'Start Selling Online For Free',
    'Tryloop provides restaurants with digital menus that are easily accessible to customers.'=>'Tryloop provides restaurants with digital menus that are easily accessible to customers.',
    'Create Restaurant'=>'Create Store',
    "Don't have a store ?"=>"Don't have a store ?",
    'Menu Screen'=>'Menu Screen',
    'Sample'=>'Sample',
    'We provide restaurants with a self-service online menu management system.'=>'We provide restaurants with a self-service online menu management system.',
    'Just add your items and create your menu. Your customers will scan your QR code to be directed to your restaurants menu.'=>'Just add your items and create your menu. Your customers will scan your QR code to be directed to your restaurants menu.',
    'Create your items'=>'Create your items',
    'First, add your items, like macaroni & cheese, chicken burritos, and drinks.'=>'First, add your items, like macaroni & cheese, chicken burritos, and drinks.',
    'Create your menu'=>'Create your menu',
    'Create menu groups and drag and drop items into the menu groups. Groups are used for menu navigation!'=>'Create menu groups and drag and drop items into the menu groups. Groups are used for menu navigation!',
    'Share your QR code'=>'Share your QR code',
    'Order stickers, or make a custom graphic with your QR code! You can download and view your QR code in your dashboard.'=>'Order stickers, or make a custom graphic with your QR code! You can download and view your QR code in your dashboard.',
    'Just open the camera and scan the QR code.'=>'Just open the camera and scan the QR code.',
    'Your menu is easily accessible to customers by just scanning a QR code. The customer will open the camera on their smartphone and point it at the QR code; they will then be prompted to visit your restaurants menu.',
    'Blazing fast menu'=> 'Blazing fast menu',
    'Custom logo and colors'=> 'Custom logo and colors',
    'User-friendly design'=> 'User-friendly design',
    'Quick &amp; easy'=> 'Quick & easy',
    'Universal access points for your store items and menus.'=> 'Universal access points for your store items and menus.',
    'Developer friendly, your store items and menus all saved in one place accessed from anywhere.'=> 'Developer friendly, your store items and menus all saved in one place accessed from anywhere.',
    'Pricing so everyone is safe!'=> 'Pricing so everyone is safe!',
    'Affordable pricing so all restaurants can offer online menus. Save time by cleaning fewer menus and save trees by reducing the need for disposable menus.'=> 'Affordable pricing so all restaurants can offer online menus. Save time by cleaning fewer menus and save trees by reducing the need for disposable menus.',
    'Annual'=> 'Annual',
    'Monthly'=>'Monthly',
    'ENTERPRISE'=> 'ENTERPRISE',
    'Our solutions do not end here; being experts in web and software applications, we offer custom solutions.'=> 'Our solutions do not end here; being experts in web and software applications, we offer custom solutions.',
    'Frequently Asked Questions'=> 'Frequently Asked Questions',
    'copyright'=> 'Copyright',
    'allright'=>'tryloop.co All right reserved.',




    
    'Home'=>'Home',
    'Terms'=>'Terms',
    'Login'=>'Login',
    'Contact'=>'Contact',
    'About' =>'About',
    'Faq' =>'Faq',
    'Contact Us'=>'Contact Us',
    'Store Login' =>'Store Login',
    'See Demo' => 'See Demo',
    'getStarted' =>'Get Started',
    'playVideo'   =>'Play Video',
     'Stay in Touch'=>'Stay in Touch',
    'Basic'=>'Basic',
    'Create an Online Store'=>'Create an Online Store',
    'You can connect a domain once your account is created'=>'You can connect a domain once your account is created',
    'Fill the below form to create an online store.'=>'Fill the below form to create an online store.',
    'Store Name'=>'Store Name',
    'Subdomain Name'=>'Subdomain Name',
    'Already have a store?'=>'Already have a store?',




];
?>